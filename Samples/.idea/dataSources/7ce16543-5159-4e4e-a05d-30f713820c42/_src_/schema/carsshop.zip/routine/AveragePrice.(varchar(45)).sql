CREATE FUNCTION `AveragePrice`(`mark` VARCHAR(45))
  RETURNS INT(11)
BEGIN
   RETURN (SELECT avg(c.price) FROM cars c 
   INNER JOIN marks m ON m.id = c.mark_id WHERE m.mark = mark);
END