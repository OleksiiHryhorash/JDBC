CREATE PROCEDURE `countClients`(OUT `info` INT(11))
  BEGIN
	SELECT Count(*) into info From clients;
END